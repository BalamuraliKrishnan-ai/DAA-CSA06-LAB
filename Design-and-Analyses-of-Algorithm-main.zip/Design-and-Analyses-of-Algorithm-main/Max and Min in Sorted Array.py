N = 8
a = [2, 4, 6, 8, 10, 12, 14, 18]
min_val = a[0]  
max_val = a[-1] 
print("Min=", min_val, "& Max=", max_val)
